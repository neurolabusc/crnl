function asl_process_subjx (ASLnames, T1name);
%function preprocesses ASL data - requires SPM8 and ASLtbx
%
% Reference: Ze Wang, Geoffrey K. Aguirre, Hengyi Rao, Jiongjiong Wang,
% Maria A. Fernandez-Seara, Anna R. Childress, and John A. Detre, Epirical
% optimization of ASL data analysis using an ASL data processing toolbox:
% ASLtbx, Magnetic Resonance Imaging, 2008, 26(2):261-9.
%
%Examples
% asl_process_subj('ep2dpcaslipat2r1.nii','T1.nii'); %single session ASL with T1
% asl_process_subj(strvcat('ep2dpcaslipat2r1.nii','ep2dpcaslipat2r2.nii'),'T1.nii'); %two sessions ASL with T1
%by Chris Rorden 

if exist('asl_perf_subtract')~=2; fprintf('%s requires ASLtbx\n',which(mfilename)); return; end;
if exist('spm_realign_asl')~=2; fprintf('%s requires ASLtbx\n',which(mfilename)); return; end;
if exist('spm')~=2; fprintf('%s requires SPM\n',which(mfilename)); return; end;

spm('Defaults','fMRI');
spm_jobman('initcfg'); % useful in SPM8 only
clear matlabbatch

if nargin <1 %no input: select ASL file[s]
 ASLnames = spm_select(inf,'image','Select 4D ASL volumes[s]');
end
if nargin <2 %no input: select T1 file[s]
 T1name = spm_select(1,'image','Select T1 anatomical scan');
end

tic; %start timer...

%% 0 - ONCE PER INDIVIDUAL normalize T1 scan using unified normalization-segmentation...
mT1name = segnormSub(T1name);
segnormwriteSub(T1name,{mT1name}, 1); %reslice bias corrected image

%% REMAINING STEPS ONCE PER SESSION
nses = length(ASLnames(:,1));
for ses = 1 : nses
    Filename = deblank (ASLnames(ses,:));
    Filename = vol4DSub(Filename);
    if length(Filename(:,1)) < 2 %single 3D image - we need 4D!
        fprintf('ERROR: %s requires multiple volumes\n',which(mfilename));
        fprintf('  Either select a 4D image or a series of 3D volumes.\n');
        return;
    end;
    fprintf('Pre-proocessing %d volumes of session %d\n',length(Filename(:,1)),ses);
    fprintf(' Assuming origin was manually set to Anterior Commissure (SPM''s ''Display'' function).\n');
    % 1 - motion correct ASL images
    spm_realign_asl(char(Filename)); %Xiaowei Zou suggested using char, Chris Rorden found no difference
    % 2 - reslice motion corrected images (and create mean)
    [meanname, Filename] = applyRealignSub(Filename); 
    % 3 - coregister ASL to T1 image
    coregSub(meanname, T1name, Filename);
    % 4 - smooth with 6mm FWHM Gaussian
    Filename = smoothSub(Filename, 6);
    % 5 - conduct CBF estimates...
    fprintf('\nWARNING: next values must be correct - please match Siemens protocol PDF with %s\n',which(mfilename));
    FirstimageType =0;
    fprintf('FirstimageType = %d (0=label,1=control)\n',FirstimageType);%0:label; 1:control; for the sequence (PASL and CASL) distributed by CFN, the first image is set to be label.
    SubtractionType = 0;
    fprintf('SubtractionType = %d (0=simple,1=surround,2=sinc)\n',SubtractionType);
    SubtractionOrder = 1;
    fprintf('SubtractionOrder = %d (0=label-control[FAIR-PASL],1=control-label[CASL])\n',SubtractionType);
    fprintf(' NOTE: if resulting CBF maps have negative values in gray matter, you have set the subtraction order incorrectly.');
    %Flag = [1MaskFlag,2MeanFlag,3CBFFlag,4BOLDFlag,5OutPerfFlag,6OutCBFFlag,7QuantFlag,8ImgFormatFlag,9D4Flag]
    Flag = [         1         1        1         0            0           1          1              1       1];
    fprintf('Mask perfusion images? = %d (0=no, 1=yes)\n',Flag(1));
    fprintf('Create mean image? = %d (0=no, 1=yes)\n',Flag(2));
    fprintf('CBF quantifications? = %d (0=no, 1=yes)\n',Flag(3));
    fprintf('Save BOLD images? = %d (0=no, 1=yes)\n',Flag(4));
    fprintf('Save Perf images? = %d (0=no, 1=yes)\n',Flag(5));
    if Flag(3) %CBFFlag
        fprintf('Save CBF images? = %d (0=no, 1=yes)\n',Flag(6));
        fprintf('Using a unique M0 value for all voxels? = %d (0=no, 1=yes)\n',Flag(7));
    end;
    fprintf('Save as NIfTI format (else Analyze)? = %d (0=no, 1=yes)\n',Flag(8));
    fprintf('Save as 4D? = %d (0=no, 1=yes)\n',Flag(9));
    Timeshift = 0.5; %NOT USED: only for sinc interpolation
    AslType = 1;
    fprintf('AslType = %d (0=PASL,1=CASL/pCASL)\n',AslType);
    labeff = 0.85; %  labeling efficiency, this should be measured for onsite scanner.
    fprintf('labeling efficiency = %g (0.95 for PASL, 0.68 for CASL, 0.85 for pCASL)\n',labeff); 
    MagType = 1;% 0=1.5T, 1=3T
    fprintf('Field Strength = %dT\n',(MagType+1)*1.5);
    Labeltime =  80*0.0185; %The CFN pCASL RF block duration is ALWAYS = 0.0185s (20 RF pulses with gaps) - 18500us 
    fprintf('Num RF Blocks = %g\n',Labeltime/0.0185); 
    Delaytime = 1.2;
    fprintf('Post Label Delay = %dusec\n',Delaytime*1000000);
    Slicetime = 35.88235294;
    fprintf('Slicetime = %gms\n',Slicetime);
    fprintf(' To compute slicetime get the minimal TR by clicking the "TR" window in the protocol panel, then slicetime=(minTR-labelingtime-delaytime)/#slices.');
    fprintf(' For example, the MCBI default sequence has a minimum TR= 2090ms plus the delay time (e.g. with a 1200ms delay, the minimum time is 3290ms)' ); 
    fprintf(' For example if MinTR=3090, labelingtime=1480, delaytime=1000, slices=17, then slicetime= 35.88235294');
      %CR note this is much longer than the EPI readout time  15.04ms = 0.47ms *32 lines [64 matrix, iPAT=2] 
    TE=12;
    fprintf('Echo Time (TE) = %gms\n',TE);  
    M0img = ''; %M0 image acquired with short TE long TR.
    M0seg = ''; %PASL only segmented white matter M0 image
    maskimg = ''; %predefined mask image 
    FullFilename = strvcat(FullpathSub('', Filename));
    % next line uses the parameters from the previous lines
    asl_perf_subtract(FullFilename,FirstimageType, SubtractionType,SubtractionOrder,Flag,Timeshift,AslType,labeff,MagType,Labeltime,Delaytime,Slicetime,TE,M0img,M0seg,maskimg);
    % 6 - apply normalization parameters to mean cbf image
    meanname = addprefix('meanCBF_0_', strvcat(deblank (Filename(1,:))  ) );
    segnormwriteSub(T1name,{meanname}, 2);
    meanname = addprefix('w', meanname);
    maskSub(meanname,0.5);
end;
fprintf('Done processing %d sessions in %0.3fsec\n',nses, toc);
%%END function asl_process

function [sesvols] = vol4DSub(sesvol1);
% input: filename from single image in 4D volume, output: list of filenames for all volumes in 4D dataset
%  example 4D file with 3 volumes input= 'img.nii', output= {'img.nii,1';'img.nii,2';'img.nii,3'}
[pth,nam,ext,vol] = spm_fileparts( deblank (sesvol1));
sesname = fullfile(pth,[nam, ext]);
hdr = spm_vol(sesname);
nvol = length(hdr);
if (nvol < 2), fprintf('Error 4D fMRI data required %s\n', sesname); return; end;
sesvols = cellstr([sesname,',1']);
for vol = 2 : nvol
        sesvols = [sesvols; [sesname,',',int2str(vol)]  ];
end;
%%END subfunction vol4DSub

function [longname] = addprefix4DSub(prefix, shortname);
% input: filenames from single image in 4D volume, output: list of filenames for all volumes in 4D dataset
%  example 4D file with 3 volumes input= {'img.nii,1';'img.nii,2';'img.nii,3'}, output= {'simg.nii,1';'simg.nii,2';'simg.nii,3'}
nsessions = length(shortname(:,1));
longname = cell(nsessions,1);
for s = 1 : nsessions 
	[pth,nam,ext,vol] = spm_fileparts(strvcat( deblank (shortname(s,:))) );
	sesname = fullfile(pth,[prefix, nam, ext,vol]);
    longname(s,1) = {sesname};
end;
%%END subfunction addprefix4DSub

function [longname] = addprefix(prefix, shortname);
%adds path if not specified
[pth,nam,ext,vol] = spm_fileparts(shortname);
longname = fullfile(pth,[prefix nam, ext]);
if exist(longname)~=2; fprintf('Warning: unable to find image %s - cd to approrpiate working directory?\n',longname); end;
longname = [longname, ',1'];
%%END subfunction addprefix

function [meanname, outname] =applyRealignSub(inname)
fprintf('Reslicing %d image with motion correction parameters.\n',length(inname(:,1)));
matlabbatch{1}.spm.spatial.realign.write.data =inname;
matlabbatch{1}.spm.spatial.realign.write.roptions.which = [2 1]; 
matlabbatch{1}.spm.spatial.realign.write.roptions.interp = 4;
matlabbatch{1}.spm.spatial.realign.write.roptions.wrap = [0 0 0];
matlabbatch{1}.spm.spatial.realign.write.roptions.mask = 1;
matlabbatch{1}.spm.spatial.realign.write.roptions.prefix = 'r';
spm_jobman('run',matlabbatch); %make mean motion corrected
meanname = addprefix('mean', strvcat(deblank (inname(1,:))  ) );
outname = addprefix4DSub('r', inname); %add 'r'ealigned prefix

%%END subfunction applyRealignSub

function coregSub(meanname, T1name, inname)
fprintf('Coregistering %s to %s, and applying transforms to %d images.\n',meanname,T1name,length(inname(:,1)) );
matlabbatch{1}.spm.spatial.coreg.estimate.ref = {T1name};
matlabbatch{1}.spm.spatial.coreg.estimate.source ={meanname};
matlabbatch{1}.spm.spatial.coreg.estimate.other = inname;
matlabbatch{1}.spm.spatial.coreg.estimate.eoptions.cost_fun = 'nmi';
matlabbatch{1}.spm.spatial.coreg.estimate.eoptions.sep = [4 2];
matlabbatch{1}.spm.spatial.coreg.estimate.eoptions.tol = [0.02 0.02 0.02 0.001 0.001 0.001 0.01 0.01 0.01 0.001 0.001 0.001];
matlabbatch{1}.spm.spatial.coreg.estimate.eoptions.fwhm = [7 7];
spm_jobman('run',matlabbatch); %make mean motion corrected
%%END subfunction coregSub

function outname = smoothSub(inname, FWHMmm);
fprintf('Smoothing %d image[s] with a %fmm FWHM Gaussian kernel\n',length(inname(:,1)),FWHMmm);
matlabbatch{1}.spm.spatial.smooth.data = inname;
matlabbatch{1}.spm.spatial.smooth.fwhm = [FWHMmm FWHMmm FWHMmm];
matlabbatch{1}.spm.spatial.smooth.dtype = 0;
matlabbatch{1}.spm.spatial.smooth.im = 0;
matlabbatch{1}.spm.spatial.smooth.prefix = 's';
spm_jobman('run',matlabbatch);
outname = addprefix4DSub('s', inname); %add 's'moothed prefix
%%END subfunction smoothSub

function [bias_t1] = segnormSub(t1);
%estimate normalization based on unified segmentation normalization of T1
fprintf('Unified segmentation normalization of %s\n',t1);
matlabbatch{1}.spm.spatial.preproc.data = {t1};
matlabbatch{1}.spm.spatial.preproc.output.GM = [0 0 1];
matlabbatch{1}.spm.spatial.preproc.output.WM = [0 0 0];
matlabbatch{1}.spm.spatial.preproc.output.CSF = [0 0 0];
matlabbatch{1}.spm.spatial.preproc.output.biascor = 1;
matlabbatch{1}.spm.spatial.preproc.output.cleanup = 0;
matlabbatch{1}.spm.spatial.preproc.opts.tpm = {fullfile(spm('Dir'),'tpm','grey.nii');fullfile(spm('Dir'),'tpm','white.nii');fullfile(spm('Dir'),'tpm','csf.nii')};
matlabbatch{1}.spm.spatial.preproc.opts.ngaus = [2;2;2;4];
matlabbatch{1}.spm.spatial.preproc.opts.regtype = 'mni';
matlabbatch{1}.spm.spatial.preproc.opts.warpreg = 1;
matlabbatch{1}.spm.spatial.preproc.opts.warpco = 25;
matlabbatch{1}.spm.spatial.preproc.opts.biasreg = 0.0001;
matlabbatch{1}.spm.spatial.preproc.opts.biasfwhm = 60;
matlabbatch{1}.spm.spatial.preproc.opts.samp = 3;
matlabbatch{1}.spm.spatial.preproc.opts.msk = {''};
spm_jobman('run',matlabbatch);
%next - return name of bias-corrected image...
[pth,nam,ext,vol] = spm_fileparts( deblank (t1));
bias_t1 = fullfile(pth,['m', nam, ext]);
%%END subfunction segnormSub

function segnormwriteSub(t1,mod, mm);
%reslice ASL/fMRI data based on previous segmentation-normalization
[pth,nam,ext,vol] = spm_fileparts( deblank (t1));
fprintf('Applying unified segmentation normalization parameters from %s to %d image[s], resliced to %fmm\n',t1,length(mod(:,1)),mm);
matlabbatch{1}.spm.spatial.normalise.write.subj.matname = {fullfile(pth,[ nam, '_seg_sn.mat'])};
matlabbatch{1}.spm.spatial.normalise.write.subj.resample = mod;
matlabbatch{1}.spm.spatial.normalise.write.roptions.preserve = 0;
matlabbatch{1}.spm.spatial.normalise.write.roptions.bb = [-78 -112 -50; 78 76 85];
matlabbatch{1}.spm.spatial.normalise.write.roptions.vox = [mm mm mm];
matlabbatch{1}.spm.spatial.normalise.write.roptions.interp = 1;
matlabbatch{1}.spm.spatial.normalise.write.roptions.wrap = [0 0 0];
matlabbatch{1}.spm.spatial.normalise.write.roptions.prefix = 'w';
spm_jobman('run',matlabbatch);
%%END subfunction segnormwriteSub

function outname = maskSub(inname, Thresh);
mask = fullfile(spm('Dir'),'apriori','brainmask.nii');
[pth,nam,ext,vol] = spm_fileparts( inname(1,:));
innameX = fullfile(pth,[nam, ext]); %remove volume label
outname = fullfile(pth,['msk' nam, ext]);
tempname = fullfile(pth,['sk' nam, ext]); 
fprintf('Masking %s with %s at a threshold of %g, resulting in %s\n',innameX,mask,Thresh,outname);
%1 Reslice mask to match image
copyfile(mask,tempname); %move mask - user may not have write permission to SPM folder
matlabbatch{1}.spm.spatial.coreg.write.ref = {innameX};
matlabbatch{1}.spm.spatial.coreg.write.source = {tempname};
matlabbatch{1}.spm.spatial.coreg.write.roptions.interp = 1;
matlabbatch{1}.spm.spatial.coreg.write.roptions.wrap = [0 0 0];
matlabbatch{1}.spm.spatial.coreg.write.roptions.mask = 0;
matlabbatch{1}.spm.spatial.coreg.write.roptions.prefix = 'm';
spm_jobman('run',matlabbatch);
delete(tempname);
%2 Apply mask to image
VImg = spm_vol(innameX);
Img = spm_read_vols(VImg);
VMsk = spm_vol(outname); 
MskImg = spm_read_vols(VMsk);
delete(outname); %<- this was the mask, we will overwrite it with masked image
VImg.fname = outname; %we will overwrite the mask
for x = 1 : size(Img,1)
	for y = 1 : size(Img,2)
		for z = 1 : size(Img,3)
			if MskImg(x,y,z) < Thresh
				Img(x,y,z) = 0;
			end;
		end; %z 
	end; %y 
end; %x 
spm_write_vol(VImg,Img);

%spm_write_vol(v,ave);

%%END subfunction maskSub

function [longname] = FullpathSub(prefix, shortname);
% input: appends path to all files (if required)
nsessions = length(shortname(:,1));
longname = cell(nsessions,1);
for s = 1 : nsessions 
	[pth,nam,ext,vol] = spm_fileparts(strvcat( deblank (shortname(s,:))) );
    if length(pth)==0; pth=pwd; end;
	sname = fullfile(pth,[prefix, nam, ext]);
    if exist(sname)~=2; fprintf('Warning: unable to find image %s - cd to approrpiate working directory.\n',sname); end;
	sname = fullfile(pth,[prefix, nam, ext,vol]);
    longname(s,1) = {sname};
end;
%%END subfunction FullpathSub
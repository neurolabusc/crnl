
# hash value = 169845956
ffts.serrprimetoolarge='Prime factor for FFT length too large. Change val'+
'ue for cMaxPrimeFactor in FFTs unit'


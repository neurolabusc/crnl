//This demo uses KeyJ's NanoJPEG decoder  http://keyj.emphy.de/nanojpeg/
// by skipping bytes you can read embedded JPEGs, for example 
// DICOM transfer Syntax 1.2.840.10008.1.2.4.50 
//  (http://www.dicomlibrary.com/dicom/transfer-syntax/)
//
//To compile
// g++ jpg50_2_tiff.cpp ujpeg.cpp write_tiff.cpp -o jp2tif
//To run with simple DICOMs
// ./jp2tif 8_50.jpg 8.tif
// ./jp2tif 24_50.jpg 24.tif
//Example with byte offset to embedded image data
// ./jp2tif 8_50_1964.dcm 8.tif 1964
// ./jp2tif 24_50_1956.dcm 24.tif 1956
//Limitations
// Only extracts 8-bit and 24-bit RGB images
#include <stdio.h>
#include <stdlib.h> //malloc, free, atoi
#include <string.h> // memcpy
#include <unistd.h> //acccess
#include <stdbool.h>

#include <iostream>
#include <fstream>
#include "ujpeg.h"
#include "write_tiff.h"

int main(int argc, char *argv[]) {
   if (argc < 2) {
		printf(" %s [input] [output] [skip]\n", argv[0]);
		printf("  input : name of jpeg file to open\n");
		printf("  output : (optional) name for output of raw data\n");
		printf("  skip : (optional) bytes to skip to find jpeg (default 0)\n");
		printf(" Example (raw jpeg)\n");
		printf("  %s 8_50.jpg 8.tif\n", argv[0]); 
		printf("  %s 24_50.jpg 24.tif\n", argv[0]);
		printf(" Example (jpeg embedded in DICOM file)\n");
		printf("  %s 8_50_1964.dcm 8.tif 1964\n", argv[0]); 
		printf("  %s 24_50_1956.dcm 24.tif 1956\n", argv[0]);
		return 0;
   }
   if( access( argv[1], F_OK ) == -1 ) {
		printf("Error: unable to find '%s'\n", argv[1]);
    	return 1;
	}
	int skipBytes = 0;
	if (argc > 3) skipBytes = atoi (argv[3]);
   
	FILE *f = fopen(argv[1], "rb");
	fseek(f, 0, SEEK_END);
    int size = (int) ftell(f);
    size = size - skipBytes;
    if (size < 8) {
        printf("Error file too small\n");
        fclose(f);
		return 1;    
    }
    char *buf = (char *)malloc(size);
    fseek(f, skipBytes, SEEK_SET);
    size = (int) fread(buf, 1, size, f);
    fclose(f);

    njInit();
    if (njDecode(buf, size)) {
        printf("Error decoding the input file.\n");
        return 1;
    }
    free(buf);
    printf("X*Y %dx%d Bytes %d \n", njGetWidth(), njGetHeight(), njGetImageSize()); 
	int frames = 1;
	if (njIsColor()) frames = 3;
	write_tiff_img ((argc > 2) ? argv[2] : ("jpeg2.tiff"), njGetImage(), njGetWidth(), njGetHeight(), 8, frames, 0);
    njDone();
    return 0;
}

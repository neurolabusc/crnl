//This demo uses Chris Rordens' lossless JPEG decoder
// This format (SOF 0xC3) is very rare outside medical images
// Note that it is common for these images to store 16-bits precision
// by skipping bytes you can read embedded JPEGs, for example 
// DICOM transfer Syntax 1.2.840.10008.1.2.4.70 
//  (http://www.dicomlibrary.com/dicom/transfer-syntax/)
//
//To compile
// g++ jpg70_2_tiff.cpp jpg_0XC3.cpp write_tiff.cpp -o jp2tif
//To run with simple DICOMs
// ./jp2tif 8_ls.jpg 8.tif
// ./jp2tif 16_ls.jpg 16.tif
// ./jp2tif 24_ls.jpg 24.tif
//Example with byte offset to embedded image data
// ./jp2tif 8_ls_2066.dcm 8.tif 2066
// ./jp2tif 16_ls_1964.dcm 16.tif 1964
// ./jp2tif 24_ls_1956.dcm 24.tif 1956
//Limitations
// Only extracts 8-bit and 24-bit RGB images
#include <stdio.h>
#include <stdlib.h> //malloc, free, atoi
#include <string.h> // memcpy
#include <unistd.h> //acccess
#include <stdbool.h>
#include <iostream>
#include <fstream>
#include "jpg_0XC3.h"
#include "write_tiff.h"

int main(int argc, char *argv[]) {
   if (argc < 2) {
		printf(" %s [input] [output] [skip]\n", argv[0]);
		printf("  input : name of jpeg file to open\n");
		printf("  output : (optional) name for output of raw data\n");
		printf("  skip : (optional) bytes to skip to find jpeg (default 0)\n");
		printf(" Example (raw jpeg)\n");
		printf("  %s 16_ls.jpg 16.tif\n", argv[0]); 
		printf("  %s 24_ls.jpg 24.tif\n", argv[0]);
		printf(" Example (jpeg embedded in DICOM file)\n");
		printf("  %s 16_ls_1964.dcm 16.tif 1964\n", argv[0]); 
		printf("  %s 24_ls_1956.dcm 24.tif 1956\n", argv[0]);
		return 0;
   }
   if( access( argv[1], F_OK ) == -1 ) {
		printf("Error: unable to find '%s'\n", argv[1]);
    	return 1;
	}
	int skipBytes = 0;
	if (argc > 3) skipBytes = atoi (argv[3]);
   
	FILE *f = fopen(argv[1], "rb");
	fseek(f, 0, SEEK_END);
    int size = (int) ftell(f);
    size = size - skipBytes;
    if (size < 8) {
        printf("Error file too small\n");
        fclose(f);
		return 1;    
    }

   bool verbose = false;
    int dimX, dimY, bits, frames;
    unsigned char * img = decode_JPEG_SOF_0XC3 (argv[1], skipBytes, verbose, &dimX, &dimY, &bits, &frames);
    if (img == NULL) return 1;
    printf("X*Y %dx%d Bytes %d \n", dimX, dimY, dimX*dimY*frames*(bits/8)); 
	write_tiff_img ((argc > 2) ? argv[2] : ("jpeg2.tiff"), img, dimX, dimY, bits, frames, 1);
    free(img);
    return 0;
}

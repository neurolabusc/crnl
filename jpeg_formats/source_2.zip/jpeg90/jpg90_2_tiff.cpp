//This demo uses Chris Rordens' lossless JPEG decoder
// This format (SOF 0xC3) is very rare outside medical images
// Note that it is common for these images to store 16-bits precision
// by skipping bytes you can read embedded JPEGs, for example 
// DICOM transfer Syntax 1.2.840.10008.1.2.4.70 
//  (http://www.dicomlibrary.com/dicom/transfer-syntax/)
//
//To compile
// g++ jpg70_2_tiff.cpp jpg_0XC3.cpp write_tiff.cpp -o jp2tif
//To run with simple JPEGs
// ./jp2tif Bretagne1.j2k 24.tiff
// ./jp2tif manix16.j2k 16.tiff
//Example with byte offset to embedded image data
// ./jp2tif manix_2056.dcm 16.tif 2056
// ./jp2tif mecanix_1282.dcm 24.tif 1282

//Limitations
// Only extracts 8-bit and 24-bit RGB images
#include <stdio.h>
#include <stdlib.h> //malloc, free, atoi
#include <string.h> // memcpy
#include <unistd.h> //acccess
#include <stdbool.h>
#include <iostream>
#include <fstream>
#include "write_tiff.h"
#include <openjpeg-2.1/openjpeg.h>//"openjpeg.h"
//#include "/usr/local/include/openjpeg-2.1/openjpeg.h"//"openjpeg.h"
// export DYLD_LIBRARY_PATH="/usr/local/lib"
//g++ jpg70_2_tiff.cpp jpg_0XC3.cpp write_tiff.cpp -I/usr/local/lib /usr/local/lib/libopenjp2.a -o jp
//g++ -O3 -I/usr/local/include jpg70_2_tiff.cpp jpg_0XC3.cpp write_tiff.cpp -o jp2tif /usr/local/lib/libopenjp2.a

unsigned char * jpc2img(opj_image_t * image)
{
    int numcmpts = image->numcomps;
    int sgnd = image->comps[0].sgnd ;
    int width = image->comps[0].w;
    int height = image->comps[0].h;
    int bpp = (image->comps[0].prec + 7) >> 3; //e.g. 12 bits requires 2 bytes
    int imgbytes = bpp * width * height * numcmpts;
    bool isOK = true;
    if (numcmpts > 1) {
        for (int c = 0; c < numcmpts; c++) { //check RGB data
            if (image->comps[0].w != image->comps[c].w) isOK = false;
            if (image->comps[0].h != image->comps[c].h) isOK = false;
            if (image->comps[0].dx != image->comps[c].dx) isOK = false;
            if (image->comps[0].dy != image->comps[c].dy) isOK = false;
            if (image->comps[0].prec != image->comps[c].prec) isOK = false;
            if (image->comps[0].sgnd != image->comps[c].sgnd) isOK = false;
            //printf("component %d w*h %d*%d bits %d sgnd %d %d*%d\n", c, image->comps[c].w, image->comps[c].h, image->comps[c].prec, image->comps[c].sgnd, image->comps[c].dx, image->comps[c].dy);
        }
        if (numcmpts != 3) isOK = false; //we only handle Gray and RedGreenBlue, not GrayAlpha or RedGreenBlueAlpha
        if (image->comps[0].prec != 8) isOK = false; //only 8-bit for RGB data
    }
    if ((image->comps[0].prec < 1) || (image->comps[0].prec > 16)) isOK = false; //currently we only handle 1 and 2 byte data
    printf("  w*h=%d*%d bits=%d signed=%d components=%d\n", width, height, bpp, sgnd, numcmpts);
    if (!isOK) {
        printf("jpeg decode failure\n");
        return NULL;
    }
    //extract the data
    if ((bpp < 1) || (bpp > 2) || (width < 1) || (height < 1) || (imgbytes < 1)) {
        printf("Unable to convert to 8 or 16-bit raw data\n");
        return NULL;
    }
    unsigned char *img = (unsigned char *)malloc(imgbytes);
    uint16_t * img16ui = (uint16_t*) img; //unsigned 16-bit
    int16_t * img16i = (int16_t*) img; //signed 16-bit
    if (sgnd) bpp = -bpp;
    if (bpp == -1) {
        printf("Unable to convert SIGNED 8-bit data.\n");
        return NULL;
    }
    //n.b. NIfTI rgb-24 are PLANAR e.g. RRR..RGGG..GBBB..B not RGBRGBRGB...RGB
    int pix = 0; //ouput pixel
    for (int cmptno = 0; cmptno < numcmpts; ++cmptno) {
        int cpix = 0; //component pixel
        int* v = image->comps[cmptno].data;
        for (int y = 0; y < height; ++y) {
            for (int x = 0; x < width; ++x) {
                switch (bpp) {
                    case 1:
                        img[pix] = (unsigned char) v[cpix];
                        break;
                    case 2:
                        img16ui[pix] = (uint16_t) v[cpix];
                        break;
                    case -2:
                        img16i[pix] = (int16_t) v[cpix];
                        break;
                }
                pix ++;
                cpix ++;
            }//for x
        } //for y
    } //for each component
    return img;
}// imagetoimg()

typedef struct bufinfo {
    unsigned char *buf;
    unsigned char *cur;
    size_t len;
} BufInfo;

static void my_stream_free (void * p_user_data) { //do nothing
	//BufInfo d = (BufInfo) p_user_data;
    //free(d.buf);
} // my_stream_free()

static OPJ_UINT32 opj_read_from_buffer(void * p_buffer, OPJ_UINT32 p_nb_bytes, BufInfo* p_file) {
    OPJ_UINT32 l_nb_read;
    if(p_file->cur + p_nb_bytes < p_file->buf + p_file->len )
        l_nb_read = p_nb_bytes;
    else
        l_nb_read = (OPJ_UINT32)(p_file->buf + p_file->len - p_file->cur);
    memcpy(p_buffer, p_file->cur, l_nb_read);
    p_file->cur += l_nb_read;
    return l_nb_read ? l_nb_read : ((OPJ_UINT32)-1);
} //opj_read_from_buffer()

static OPJ_UINT32 opj_write_from_buffer(void * p_buffer, OPJ_UINT32 p_nb_bytes, BufInfo* p_file) {
    memcpy(p_file->cur,p_buffer, p_nb_bytes);
    p_file->cur += p_nb_bytes;
    p_file->len += p_nb_bytes;
    return p_nb_bytes;
} // opj_write_from_buffer()

static OPJ_SIZE_T opj_skip_from_buffer(OPJ_SIZE_T p_nb_bytes, BufInfo * p_file) {
    if(p_file->cur + p_nb_bytes < p_file->buf + p_file->len )
    {
        p_file->cur += p_nb_bytes;
        return p_nb_bytes;
    }
    p_file->cur = p_file->buf + p_file->len;
    return (OPJ_SIZE_T)-1;
} //opj_skip_from_buffer()

static OPJ_BOOL opj_seek_from_buffer(OPJ_SIZE_T p_nb_bytes, BufInfo * p_file) {
    if(p_file->cur + p_nb_bytes < p_file->buf + p_file->len ) {
        p_file->cur += p_nb_bytes;
        return OPJ_TRUE;
    }
    p_file->cur = p_file->buf + p_file->len;
    return OPJ_FALSE;
} //opj_seek_from_buffer()

opj_stream_t* opj_stream_create_buffer_stream(BufInfo* p_file, OPJ_UINT32 p_size, OPJ_BOOL p_is_read_stream) {
    opj_stream_t* l_stream;
    if(! p_file) return NULL;
    l_stream = opj_stream_create(p_size, p_is_read_stream);
    if(! l_stream) return NULL;
    opj_stream_set_user_data(l_stream, p_file , my_stream_free);
    opj_stream_set_user_data_length(l_stream, p_file->len);
    opj_stream_set_read_function(l_stream,  (opj_stream_read_fn) opj_read_from_buffer);
    opj_stream_set_write_function(l_stream, (opj_stream_write_fn) opj_write_from_buffer);
    opj_stream_set_skip_function(l_stream, (opj_stream_skip_fn) opj_skip_from_buffer);
    opj_stream_set_seek_function(l_stream, (opj_stream_seek_fn) opj_seek_from_buffer);
    return l_stream;
} //opj_stream_create_buffer_stream()

int jp_skip (const char *fn, const char * outfn, int dcmimageStart) {
    unsigned char * ret = NULL;
    //OpenJPEG library is not well documented and has changed between versions
    //Since the JPEG is embedded in a DICOM we need to skip bytes at the start of the file
    // In theory we might also want to strip data that exists AFTER the image, see gdcmJPEG2000Codec.c
    opj_dparameters_t params;
    opj_codec_t *codec;
    opj_image_t *jpx;
    opj_stream_t *stream;
    FILE *reader = fopen(fn, "rb");
    fseek(reader, 0, SEEK_END);
    long size = ftell(reader)- dcmimageStart;
    if (size <= 8) return 1;
    fseek(reader, dcmimageStart, SEEK_SET);
    unsigned char *data = (unsigned char*) malloc(size);
    fread(data, 1, size, reader);
    fclose(reader);
    OPJ_CODEC_FORMAT format = OPJ_CODEC_JP2;
    //DICOM JPEG2k is SUPPOSED to start with codestream, but some vendors include a header
    if (data[0] == 0xFF && data[1] == 0x4F && data[2] == 0xFF && data[3] == 0x51) format = OPJ_CODEC_J2K;
    opj_set_default_decoder_parameters(&params);
    BufInfo dx;
    dx.buf = data;
    dx.cur = data;
    dx.len = size;
    stream = opj_stream_create_buffer_stream(&dx, (OPJ_UINT32)size, true);
    if (stream == NULL) return 1;
    codec = opj_create_decompress(format);
    // setup the decoder decoding parameters using user parameters
    if ( !opj_setup_decoder(codec, &params) ) goto cleanup2;
    // Read the main header of the codestream and if necessary the JP2 boxes
    if(! opj_read_header( stream, codec, &jpx)){
        printf( "OpenJPEG error: failed to read the header %s\n",fn);
        goto cleanup2;
    }
    // Get the decoded image
    if ( !( opj_decode(codec, stream, jpx) && opj_end_decompress(codec,stream) ) ) {
        printf( "OpenJPEG error: j2k_to_image: failed to decode %s\n",fn);
        goto cleanup1;
    }
    ret = jpc2img(jpx);
    if (ret != NULL) {
    	write_tiff_img (outfn, ret, jpx->comps[0].w, jpx->comps[0].h, jpx->comps[0].prec, jpx->numcomps, 1);
    	free(ret);
    }
  cleanup1:
    opj_image_destroy(jpx);
  cleanup2:
    free(dx.buf);
    opj_stream_destroy(stream);
    opj_destroy_codec(codec);
    return 0;
} //jp_skip()

int main(int argc, char *argv[]) {
   if (argc < 2) {
		printf(" %s [input] [output] [skip]\n", argv[0]);
		printf("  input : name of jpeg file to open\n");
		printf("  output : (optional) name for output of raw data\n");
		printf("  skip : (optional) bytes to skip to find jpeg (default 0)\n");
		printf(" Example (raw jpeg)\n");
		printf("  %s Bretagne1.j2k 24.tiff\n", argv[0]); 
		printf("  %s manix16.j2k 16.tiff\n", argv[0]);
		printf(" Example (jpeg embedded in DICOM file)\n");
		printf("  %s manix_2056.dcm 16.tif 2056\n", argv[0]); 
		printf("  %s mecanix_1282.dcm 24.tif 1282\n", argv[0]);
		return 0;
   }
   if( access( argv[1], F_OK ) == -1 ) {
		printf("Error: unable to find '%s'\n", argv[1]);
    	return 1;
	}
	int skipBytes = 0;
	if (argc > 3) skipBytes = atoi (argv[3]);
   	jp_skip(argv[1], (argc > 2) ? argv[2] : ("jpeg2.tiff"), skipBytes);
    return 0;
}
